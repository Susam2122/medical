 import java.util.Scanner;
 public class Patient extends Hospital{
        private String disease;
        public Patient(){
        this.disease = disease;
    }
 
    public void setdisease(String disease){
        this.disease = disease;
    }
    public String getdisease(){
        return disease;
    }
    
    /*@Override
    public void choice(){
        Scanner make = new Scanner(System.in);
        System.out.println("enter your disease");
        disease = make.nextLine();
        System.out.println(" disease " + disease);
    }*/
 }