import java.util.Scanner;
public class Test{
public static void main (String[]args){
        Hospital get = new Hospital();
        get.choice();
        System.out.println("Would you like to see a Doctor\nclick:1");
        //Patient get2 = new Patient( );
        //get2.choice();
        Scanner may = new Scanner(System.in);
        int n = may.nextInt();
        if(n==1){
         Doctor get1 = new Doctor();
        get1.choice();
        } 
        else {
                System.out.println("give us your feedback");
                Scanner mk = new Scanner(System.in);
                String comment = mk.nextLine();
        }
        System.out.println("Thanks for using our services");
        
        
}
}
