import java.util.Scanner;
public class Hospital{
    private String name;
    private String address;
    private String service;
    private String dob;
    private int phone_no;
    protected String medicine;
    private String gender;
    private String symptoms;
    public Hospital (){
        this.name = name;
        this.address = address;
        this.service = service;
        this.dob = dob;
        this.phone_no = phone_no;
        this.medicine = medicine;
        this.gender = gender;
        this.symptoms = symptoms;
    }
    public String getname(){
        return name;
    }
    public String getaddress(){
        return address;
    }
    public String getservice(){
        return service;
    }
    public String getdob(){
        return dob;
    }
    public int getphone_no(){
        return phone_no;
    }
    public String getmedicine(){
        return medicine;
    } 
    public String getgender(){
        return gender;
    }
    public String getsymptoms(){
        return symptoms;
    }
   
    public void choice(){
        Scanner make  = new Scanner(System.in);
        System.out.println("FILL REQUIREMENT");
        System.out.println("Enter your name ");
        Scanner makex = new Scanner(System.in);
        name = makex.nextLine();
        System.out.println("enter your gender");
        gender = make.nextLine();
         System.out.println("enter your dob");
        dob = make.nextLine();
        System.out.println("enter your address");
        address = make.nextLine();
        System.out.println("enter your phone_no");
        Scanner makey = new Scanner(System.in);
        phone_no = makey.nextInt();
        System.out.println("Enter your service");
        service = make.nextLine();
        System.out.println("Enter your symptoms");
        symptoms = make.nextLine();
       
        System.out.println( "Your name is " +name+ "\nYour address is " + address + "\nYour service is " +service+
        "\nYour dob is " +dob+  "\nYour phone_no is " +phone_no+ " \nYour gender is " +gender);
        
    
    }
    }

