import java.util.Scanner;
public class Doctor extends Hospital{
        private String staffID;
        private String disease;
        public Doctor(){
        this.staffID =staffID;
        this.disease = disease;
    }
    
    public void  setstaff_id (String newstaff_id){
        this.staffID = newstaff_id;
    }
    public String getstaff_id(){
        return staffID;
    }
    public void setdisease(String disease){
        this.disease = disease;
    }
    public String getdisease(){
        return disease;
    }
    
        @Override
        public void choice(){
            String password = "str123";
            Scanner make = new Scanner(System.in);
            System.out.println("enter your staffID");
            staffID = make.nextLine();
            if( staffID.equalsIgnoreCase(password))
            {
                System.out.println("enter your disease");
             disease = make.nextLine();
             System.out.println("enter your medicine");
             medicine = make.next();
            System.out.println("Your problem is "+disease+"\nmedicine is "+medicine+"\nby\t"+staffID);
            }else{
                System.out.println("invalid login");
                 
            }
           
        }
}